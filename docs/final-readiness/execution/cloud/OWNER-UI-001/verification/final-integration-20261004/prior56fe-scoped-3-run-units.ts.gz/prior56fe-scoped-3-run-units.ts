import {captureTestCommand} from '../ui001-final-e61c84b1/scripts/test-all.ts'
import {createHash} from 'node:crypto'
import {readFile,writeFile,mkdir} from 'node:fs/promises'
import {join} from 'node:path'
const root='/Users/t/Projects/2026-10-03/prior-conversation-with-codex-conversation-role-3'
const repository=join(root,'work/ui001-final-e61c84b1'), artifact=join(root,'work/ui001-final-scoped-56fe')
const bun=join(root,'work/toolchain/node_modules/.bin/bun'),nodeDirectory=join(root,'work/toolchain/node24/node_modules/.bin')
const sha=(data:Uint8Array|string)=>createHash('sha256').update(data).digest('hex')
const paths=['apps/electron/src/renderer/pages/__tests__/rox-readiness-ui-001.note-route-lifecycle.test.ts','packages/server-core/src/handlers/rpc/__tests__/notes-missing.test.ts','packages/server-core/src/handlers/rpc/__tests__/notes-missing-transport.test.ts','packages/server-core/src/handlers/rpc/__tests__/notes-write-capability.test.ts','apps/electron/src/renderer/knowledge/__tests__/kernel-availability.test.ts','apps/electron/src/renderer/lib/__tests__/platform-shortcuts.test.ts','apps/electron/src/renderer/pages/__tests__/shortcut-hints.test.ts','packages/shared/src/i18n/__tests__/locale-parity.test.ts']
const subjects=['scripts/test-all.ts','apps/electron/src/renderer/pages/NotesPage.tsx','packages/server-core/src/handlers/rpc/notes.ts','packages/server-core/src/handlers/rpc/content.ts','packages/server-core/src/handlers/rpc/note-read-error.ts','apps/electron/src/renderer/knowledge/KnowledgeHome.tsx','apps/electron/src/renderer/knowledge/KnowledgeNotebookTree.tsx','apps/electron/src/renderer/knowledge/kernel-availability.ts','apps/electron/src/renderer/lib/platform.ts','apps/electron/src/renderer/pages/TasksPage.tsx','apps/electron/src/renderer/pages/tasks/TaskDetail.tsx','apps/electron/src/renderer/pages/tasks/QuickEntry.tsx','apps/electron/src/renderer/components/memory/MemoryScreen.tsx','packages/shared/src/i18n/locales/ar.json','packages/shared/src/i18n/locales/de.json','packages/shared/src/i18n/locales/en.json','packages/shared/src/i18n/locales/es.json','packages/shared/src/i18n/locales/fr.json','packages/shared/src/i18n/locales/hu.json','packages/shared/src/i18n/locales/ja.json','packages/shared/src/i18n/locales/ko.json','packages/shared/src/i18n/locales/pl.json','packages/shared/src/i18n/locales/ru.json','packages/shared/src/i18n/locales/zh-Hans.json','packages/shared/src/i18n/locales/zh-Hant.json']
const bindings=async()=>Object.fromEntries(await Promise.all([...paths,...subjects].map(async path=>[path,sha(await readFile(join(repository,path)))])))
const environment={...process.env,PATH:nodeDirectory+':'+join(root,'work/toolchain/node_modules/.bin')+':'+process.env.PATH,NO_COLOR:'1'}
for(const key of Object.keys(environment)) if (/(?:TOKEN|SECRET|PASSWORD|API_KEY|CREDENTIAL|AUTHORIZATION|WORKSPACE_TEST_CONFIG|DATABASE_URL|PGPASSWORD)/i.test(key)) delete environment[key]
const originalBindings=await bindings()
const state:any={task_id:'source_review',attempt_id:'28586c49ffa159b4e2a4d554df46b9e0',packet_hash:'2ad67e8072153eaf29a7785d31cc91b584afa336883eb3a9d2e02abcaf1526e3',head:'56fe8105a21be0bfcb523a01b863ef824f257581',repository,bun:'1.3.14',outerNode:'24.21.0',source_before:originalBindings,source_writes:false,original_test_bodies_assertions_deadlines_unchanged:true,results:[],fullDoDClosed:false}
await writeFile(join(artifact,'unit-start.json'),JSON.stringify(state,null,2)+'\n')
for(const [index,path] of paths.entries()){
 const name=path.split('/').pop()!,home=join(artifact,'private-'+index,'home'),temporary=join(artifact,'private-'+index,'tmp'),config=join(home,'rox')
 for(const directory of [home,temporary,config,join(home,'xdg-config'),join(home,'xdg-cache'),join(home,'xdg-data')]) await mkdir(directory,{recursive:true,mode:0o700})
 const env={...environment,HOME:home,TMPDIR:temporary,XDG_CONFIG_HOME:join(home,'xdg-config'),XDG_CACHE_HOME:join(home,'xdg-cache'),XDG_DATA_HOME:join(home,'xdg-data'),ROX_CONFIG_DIR:config,CRAFT_CONFIG_DIR:config}
 const command=[bun,'test','--timeout','30000',path],log=join(artifact,String(index+1).padStart(2,'0')+'-'+name+'.log'),started=Date.now()
 process.stdout.write(JSON.stringify({starting:index+1,path})+'\n')
 let child:any
 try{child=await captureTestCommand(command,{cwd:repository,environment:env,log,timeoutMs:300000})}catch(error){child={captureError:error instanceof Error?error.message:String(error),exitCode:null,stdout:'',stderr:''}}
 const text=child.stdout+'\n'+child.stderr
 const summary={passed:Number(text.match(/\n\s*(\d+) pass/)?.[1]??0),failed:Number(text.match(/\n\s*(\d+) fail/)?.[1]??0),skipped:Number(text.match(/\n\s*(\d+) skip/)?.[1]??0),errors:Number(text.match(/\n\s*(\d+) errors?/)?.[1]??0),assertions:Number(text.match(/\n\s*(\d+) expect\(\) calls/)?.[1]??0)}
 const entry={path,command,log,log_sha256:sha(await readFile(log).catch(()=>new Uint8Array())),source_before_sha256:originalBindings[path],source_after_sha256:sha(await readFile(join(repository,path))),elapsed_ms:Date.now()-started,summary,...Object.fromEntries(Object.entries(child).filter(([key])=>!['stdout','stderr'].includes(key)))}
 state.results.push(entry);await writeFile(join(artifact,'unit-runs.json'),JSON.stringify(state,null,2)+'\n')
 process.stdout.write(JSON.stringify({finished:index+1,exitCode:child.exitCode,nodeVersion:child.nodeVersion,summary,elapsed_ms:entry.elapsed_ms,log_sha256:entry.log_sha256})+'\n')
 if(child.exitCode!==0)process.stdout.write(text.slice(-6500)+'\n')
}
state.source_after=await bindings();state.sources_stable=JSON.stringify(state.source_after)===JSON.stringify(state.source_before);state.all_exit_zero=state.results.every((r:any)=>r.exitCode===0);state.totals=Object.fromEntries(['passed','failed','skipped','errors','assertions'].map(key=>[key,state.results.reduce((sum:number,r:any)=>sum+r.summary[key],0)]))
await writeFile(join(artifact,'unit-result.json'),JSON.stringify(state,null,2)+'\n')
process.stdout.write(JSON.stringify({result:join(artifact,'unit-result.json'),sha256:sha(await readFile(join(artifact,'unit-result.json'))),totals:state.totals,sources_stable:state.sources_stable})+'\n')
