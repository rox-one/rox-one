import {captureTestCommand} from '../ui001-final-e61c84b1/scripts/test-all.ts'
import {createHash} from 'node:crypto'
import {readFile,writeFile,mkdir} from 'node:fs/promises'
import {join} from 'node:path'
const root='/Users/t/Projects/2026-10-03/prior-conversation-with-codex-conversation-role-3',repository=join(root,'work/ui001-final-e61c84b1'),artifact=join(root,'work/ui001-final-scoped-56fe')
const bun=join(root,'work/toolchain/node_modules/.bin/bun'),nodeDirectory=join(root,'work/toolchain/node24/node_modules/.bin')
const chromium=join(repository,'work/.gstack-test-runtime/browsers/chromium_headless_shell-1234/chrome-headless-shell-mac-arm64/chrome-headless-shell')
const sha=(data:Uint8Array|string)=>createHash('sha256').update(data).digest('hex')
const path='apps/electron/src/renderer/knowledge/__tests__/kernel-availability.browser.test.ts'
const subjects=[path,'scripts/test-all.ts','apps/electron/src/renderer/knowledge/KnowledgeHome.tsx','apps/electron/src/renderer/knowledge/KnowledgeNotebookTree.tsx','apps/electron/src/renderer/knowledge/kernel-availability.ts','apps/electron/src/renderer/knowledge/__tests__/fixtures/availability/vite.config.ts','apps/electron/src/renderer/knowledge/__tests__/fixtures/availability/context.tsx','apps/electron/src/renderer/knowledge/__tests__/fixtures/availability/main.tsx','apps/electron/src/renderer/knowledge/__tests__/fixtures/availability/index.html']
const bindings=async()=>Object.fromEntries(await Promise.all(subjects.map(async p=>[p,sha(await readFile(join(repository,p)))])))
const home=join(artifact,'browser-private-home'),temporary=join(artifact,'browser-private-tmp'),config=join(home,'rox')
for(const directory of [home,temporary,config,join(home,'xdg-config'),join(home,'xdg-cache'),join(home,'xdg-data')])await mkdir(directory,{recursive:true,mode:0o700})
const environment={...process.env,PATH:nodeDirectory+':'+join(root,'work/toolchain/node_modules/.bin')+':'+process.env.PATH,HOME:home,TMPDIR:temporary,XDG_CONFIG_HOME:join(home,'xdg-config'),XDG_CACHE_HOME:join(home,'xdg-cache'),XDG_DATA_HOME:join(home,'xdg-data'),ROX_CONFIG_DIR:config,CRAFT_CONFIG_DIR:config,CHROMIUM_EXECUTABLE:chromium,NO_COLOR:'1'}
for(const key of Object.keys(environment))if(/(?:TOKEN|SECRET|PASSWORD|API_KEY|CREDENTIAL|AUTHORIZATION|WORKSPACE_TEST_CONFIG|DATABASE_URL|PGPASSWORD)/i.test(key))delete environment[key]
const before=await bindings(),chromiumSha=sha(await readFile(chromium))
if(chromiumSha!=='7687bff7cb2db075f250e6d5848bbc8838cac3802ac3952a899c574f8eccab45')throw Error('Qualified Chromium hash mismatch')
const log=join(artifact,'09-kernel-availability.browser.test.ts.log'),command=[bun,'test','--timeout','60000',path]
const start={task_id:'source_review',attempt_id:'28586c49ffa159b4e2a4d554df46b9e0',packet_hash:'2ad67e8072153eaf29a7785d31cc91b584afa336883eb3a9d2e02abcaf1526e3',head:'56fe8105a21be0bfcb523a01b863ef824f257581',source_before:before,command,chromium,chromium_sha256:chromiumSha,port:5269,preflight_port_unoccupied:true,source_writes:false,test_bodies_assertions_explicit_deadlines_unchanged:true,foreground_ui:false,provider_calls:false,fullDoDClosed:false}
await writeFile(join(artifact,'browser-start.json'),JSON.stringify(start,null,2)+'\n')
process.stdout.write(JSON.stringify({starting:true,command,chromiumSha})+'\n')
const started=Date.now();let child:any
try{child=await captureTestCommand(command,{cwd:repository,environment,log,timeoutMs:360000})}catch(error){child={captureError:error instanceof Error?error.message:String(error),exitCode:null,stdout:'',stderr:''}}
const text=child.stdout+'\n'+child.stderr
const summary={passed:Number(text.match(/\n\s*(\d+) pass/)?.[1]??0),failed:Number(text.match(/\n\s*(\d+) fail/)?.[1]??0),skipped:Number(text.match(/\n\s*(\d+) skip/)?.[1]??0),errors:Number(text.match(/\n\s*(\d+) errors?/)?.[1]??0),assertions:Number(text.match(/\n\s*(\d+) expect\(\) calls/)?.[1]??0)}
const after=await bindings(),result={...start,source_after:after,sources_stable:JSON.stringify(before)===JSON.stringify(after),summary,elapsed_ms:Date.now()-started,log,log_sha256:sha(await readFile(log).catch(()=>new Uint8Array())),...Object.fromEntries(Object.entries(child).filter(([key])=>!['stdout','stderr'].includes(key)))}
await writeFile(join(artifact,'browser-result.json'),JSON.stringify(result,null,2)+'\n')
process.stdout.write(JSON.stringify({result:join(artifact,'browser-result.json'),sha256:sha(await readFile(join(artifact,'browser-result.json'))),summary,exitCode:child.exitCode,sources_stable:result.sources_stable})+'\n')
process.stdout.write(text.slice(-12000)+'\n')
